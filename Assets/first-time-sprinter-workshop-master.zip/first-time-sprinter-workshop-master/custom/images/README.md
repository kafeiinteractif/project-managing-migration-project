Use this directory to store background and other images.
